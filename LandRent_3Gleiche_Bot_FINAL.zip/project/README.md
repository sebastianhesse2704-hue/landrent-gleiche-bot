# LandRent 3 Gleiche Bot – FINAL

Android 11+ AccessibilityService bot prototype for the LandRent “3 Gleiche” minigame.

Important: Android permissions/service behavior depend on the phone and OS. This build adds explicit screenshot capability, a diagnostic service test, and persistent start state. The visual move selector remains conservative and should be treated as a prototype rather than a guaranteed perfect game solver.
