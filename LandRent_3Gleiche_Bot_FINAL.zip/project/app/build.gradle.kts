plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.landrent.dreigleichebot"
    compileSdk = 35

    defaultConfig {
        applicationId = "de.landrent.dreigleichebot"
        minSdk = 30
        targetSdk = 35
        versionCode = 3
        versionName = "2.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
