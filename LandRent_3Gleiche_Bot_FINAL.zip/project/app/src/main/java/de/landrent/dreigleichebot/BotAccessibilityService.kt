package de.landrent.dreigleichebot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent

class BotAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: BotAccessibilityService? = null
        const val PREFS = "bot_prefs"
        const val KEY_START_REQUESTED = "start_requested"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private val engine = BotEngine()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        if (getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_START_REQUESTED, false)) {
            startBotInternal()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        stopBotInternal(false)
    }

    override fun onDestroy() {
        stopBotInternal(false)
        instance = null
        super.onDestroy()
    }

    fun startBot() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean(KEY_START_REQUESTED, true).apply()
        startBotInternal()
    }

    fun stopBot() = stopBotInternal(true)

    private fun startBotInternal() {
        if (running) return
        running = true
        handler.removeCallbacksAndMessages(null)
        scheduleStep(250)
    }

    private fun stopBotInternal(clearRequest: Boolean) {
        running = false
        handler.removeCallbacksAndMessages(null)
        if (clearRequest) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean(KEY_START_REQUESTED, false).apply()
        }
    }

    private fun scheduleStep(delay: Long) {
        if (running) handler.postDelayed({ step() }, delay)
    }

    private fun step() {
        if (!running) return
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    var bitmap: Bitmap? = null
                    try {
                        val buffer = result.hardwareBuffer
                        val hardware = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                        bitmap = hardware?.copy(Bitmap.Config.ARGB_8888, false)
                        buffer.close()
                        if (bitmap != null) {
                            engine.chooseMove(bitmap!!)?.let { tap(it.x, it.y) }
                        }
                    } catch (_: Throwable) {
                        // Ein einzelner Screenshot darf den Bot nicht beenden.
                    } finally {
                        bitmap?.recycle()
                    }
                    scheduleStep(700)
                }

                override fun onFailure(errorCode: Int) {
                    scheduleStep(1200)
                }
            })
        } catch (_: Throwable) {
            scheduleStep(1500)
        }
    }

    private fun tap(x: Float, y: Float) {
        if (!running) return
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
