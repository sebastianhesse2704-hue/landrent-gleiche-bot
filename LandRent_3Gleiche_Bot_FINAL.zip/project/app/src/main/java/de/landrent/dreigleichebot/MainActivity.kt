package de.landrent.dreigleichebot

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 32, 24, 24)
        }

        val title = TextView(this).apply {
            text = "LandRent – 3 Gleiche Bot"
            textSize = 25f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 18)
        }
        root.addView(title)

        val info = TextView(this).apply {
            text = "Der Dienst muss in den Android-Bedienungshilfen aktiviert sein.\n\nDer Startstatus wird gespeichert, damit der Bot nach dem Verbinden automatisch weiterläuft."
            textSize = 16f
            setPadding(0, 0, 0, 18)
        }
        root.addView(info)

        status = TextView(this).apply {
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 18)
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "BEDIENUNGSHILFE ÖFFNEN"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        root.addView(Button(this).apply {
            text = "BOT STARTEN"
            setOnClickListener { requestStart() }
        })

        root.addView(Button(this).apply {
            text = "BOT STOPPEN"
            setOnClickListener {
                getSharedPreferences(BotAccessibilityService.PREFS, MODE_PRIVATE)
                    .edit().putBoolean(BotAccessibilityService.KEY_START_REQUESTED, false).apply()
                BotAccessibilityService.instance?.stopBot()
                updateStatus()
            }
        })

        root.addView(Button(this).apply {
            text = "DIENST TESTEN"
            setOnClickListener {
                val service = BotAccessibilityService.instance
                if (service != null) {
                    Toast.makeText(this@MainActivity, "Bedienungshilfe-Dienst ist verbunden.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this@MainActivity, "Dienst ist NICHT verbunden. Bitte Bedienungshilfe prüfen.", Toast.LENGTH_LONG).show()
                }
                updateStatus()
            }
        })

        setContentView(root)
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) updateStatus()
    }

    private fun requestStart() {
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "Bitte zuerst die Bedienungshilfe aktivieren.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }

        getSharedPreferences(BotAccessibilityService.PREFS, MODE_PRIVATE)
            .edit().putBoolean(BotAccessibilityService.KEY_START_REQUESTED, true).apply()

        val service = BotAccessibilityService.instance
        if (service != null) {
            service.startBot()
            updateStatus()
        } else {
            Toast.makeText(this, "Android verbindet den Dienst noch. Bitte 2 Sekunden warten und erneut TESTEN/STARTEN.", Toast.LENGTH_LONG).show()
            updateStatus()
        }
    }

    private fun updateStatus() {
        val enabled = isAccessibilityEnabled()
        val connected = BotAccessibilityService.instance != null
        val requested = getSharedPreferences(BotAccessibilityService.PREFS, MODE_PRIVATE)
            .getBoolean(BotAccessibilityService.KEY_START_REQUESTED, false)
        status.text = when {
            !enabled -> "Status: Bedienungshilfe AUS"
            !connected -> "Status: aktiviert, aber Dienst nicht verbunden"
            requested -> "Status: DIENST VERBUNDEN – BOT ANGEFORDERT"
            else -> "Status: DIENST VERBUNDEN"
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val raw = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val expected = ComponentName(this, BotAccessibilityService::class.java).flattenToString()
        return raw.split(':').any { it.equals(expected, ignoreCase = true) }
    }
}
