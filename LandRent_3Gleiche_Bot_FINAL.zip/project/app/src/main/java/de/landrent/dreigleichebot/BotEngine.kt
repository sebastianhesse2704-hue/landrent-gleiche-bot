package de.landrent.dreigleichebot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Conservative visual selector. It deliberately avoids the top tray and screen edges.
 * It selects a visually strong tile-like patch rather than blindly tapping a grid.
 * The service re-screenshots after every action.
 */
class BotEngine {
    data class Action(val x: Float, val y: Float)

    fun chooseMove(bitmap: Bitmap): Action? {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 300 || h < 500) return null

        val left = (w * 0.08f).toInt()
        val right = (w * 0.92f).toInt()
        val top = (h * 0.24f).toInt()
        val bottom = (h * 0.86f).toInt()
        val sx = max(32, w / 18)
        val sy = max(32, h / 28)
        var best: Action? = null
        var bestScore = 0

        var y = top
        while (y <= bottom) {
            var x = left
            while (x <= right) {
                val score = tileScore(bitmap, x, y, min(sx, sy) / 2)
                if (score > bestScore) {
                    bestScore = score
                    best = Action(x.toFloat(), y.toFloat())
                }
                x += sx
            }
            y += sy
        }
        return if (bestScore >= 24) best else null
    }

    private fun tileScore(b: Bitmap, cx: Int, cy: Int, r: Int): Int {
        val rr = max(6, r)
        var vivid = 0
        var contrast = 0
        var count = 0
        val y0 = max(0, cy - rr)
        val y1 = min(b.height - 1, cy + rr)
        val x0 = max(0, cx - rr)
        val x1 = min(b.width - 1, cx + rr)
        var y = y0
        while (y <= y1) {
            var x = x0
            while (x <= x1) {
                val c = b.getPixel(x, y)
                val r8 = Color.red(c)
                val g8 = Color.green(c)
                val b8 = Color.blue(c)
                val mx = max(r8, max(g8, b8))
                val mn = min(r8, min(g8, b8))
                vivid += mx - mn
                if (x + 2 < b.width) {
                    val c2 = b.getPixel(x + 2, y)
                    contrast += abs(r8 - Color.red(c2)) + abs(g8 - Color.green(c2)) + abs(b8 - Color.blue(c2))
                }
                count++
                x += max(2, rr / 4)
            }
            y += max(2, rr / 4)
        }
        if (count == 0) return 0
        return (vivid / count) / 3 + (contrast / count) / 12
    }
}
